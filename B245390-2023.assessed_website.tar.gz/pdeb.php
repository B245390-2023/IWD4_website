<?php
// pdeb.php
include 'redir.php'; // Ensures the user is redirected if not logged in

session_start();

// Display the current supplier mask
$supmask = $_SESSION['supmask'] ?? 0; // Use 0 as a default if not set
echo "Current Supplier Mask: " . $supmask . "<br>";

// Assuming there are 5 manufacturers, the mask would be 31 (11111 in binary)
// Adjust this value to match the number of your actual manufacturers
$_SESSION['supmask'] = 31; // Reset mask to all manufacturers

// Provide a link to go back or to another page
?>
<a href="complib.php">Return to main page</a>
