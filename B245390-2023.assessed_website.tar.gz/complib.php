<?php
// complib.php
include 'login.php'; // Include the login script to connect to the database.
session_start(); // Start the session.

// Define the number of results per page
$perPage = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

// Retrieve columns from Compounds table for dropdown menus.
try {
    $compoundColumns = $conn->query("DESCRIBE Compounds")->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    echo "Error fetching compound information: " . $e->getMessage();
    exit;
}

// Initialize variables
$results = [];
$totalRows = 0;

// If the search form is submitted.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $searchField1 = $_POST['searchField1'] ?? '';
    $searchValue1 = $_POST['searchValue1'] ?? '';
    $searchField2 = $_POST['searchField2'] ?? '';
    $searchValue2 = $_POST['searchValue2'] ?? '';

    // Prepare the SQL query for pagination and execute it.
    $sql = "SELECT SQL_CALC_FOUND_ROWS Compounds.*, Manufacturers.name AS ManufacturerName
            FROM Compounds
            JOIN Manufacturers ON Compounds.ManuID = Manufacturers.id
            WHERE Compounds.$searchField1 = :searchValue1 AND Compounds.$searchField2 = :searchValue2
            ORDER BY Compounds.id LIMIT :offset, :perPage";

    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':searchValue1', $searchValue1);
        $stmt->bindParam(':searchValue2', $searchValue2);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindParam(':perPage', $perPage, PDO::PARAM_INT);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get the total rows found
        $totalRows = $conn->query("SELECT FOUND_ROWS()")->fetchColumn();
        $totalPages = ceil($totalRows / $perPage);
    } catch (PDOException $e) {
        echo "Error performing search: " . $e->getMessage();
    }
}

// Display the search form.
?>
<form action="complib.php" method="post">
    Select the first criteria:
    <select name="searchField1">
        <?php foreach ($compoundColumns as $column): ?>
            <option value="<?php echo htmlspecialchars($column); ?>"><?php echo htmlspecialchars($column); ?></option>
        <?php endforeach; ?>
    </select>
    Value: <input type="text" name="searchValue1"><br>
    
    Select the second criteria:
    <select name="searchField2">
        <?php foreach ($compoundColumns as $column): ?>
            <option value="<?php echo htmlspecialchars($column); ?>"><?php echo htmlspecialchars($column); ?></option>
        <?php endforeach; ?>
    </select>
    Value: <input type="text" name="searchValue2"><br>
    
    <input type="submit" value="Search">
</form>

<?php if ($results): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NATM</th>
                <th>NCAR</th>
                <th>NNIT</th>
                <th>NOXY</th>
                <th>NSUL</th>
                <th>NCYCL</th>
                <th>NHDON</th>
                <th>NHACC</th>
                <th>NROTB</th>
                <th>Manufacturer</th>
                <th>CATN</th>
                <th>MW</th>
                <th>TPSA</th>
                <th>XLogP</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($results as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['natm']); ?></td>
                <td><?php echo htmlspecialchars($row['ncar']); ?></td>
                <td><?php echo htmlspecialchars($row['nnit']); ?></td>
                <td><?php echo htmlspecialchars($row['noxy']); ?></td>
                <td><?php echo htmlspecialchars($row['nsul']); ?></td>
                <td><?php echo htmlspecialchars($row['ncycl']); ?></td>
                <td><?php echo htmlspecialchars($row['nhdon']); ?></td>
                <td><?php echo htmlspecialchars($row['nhacc']); ?></td>
                <td><?php echo htmlspecialchars($row['nrotb']); ?></td>
                <td><?php echo htmlspecialchars($row['ManufacturerName']); ?></td>
                <td><?php echo htmlspecialchars($row['catn']); ?></td>
                <td><?php echo htmlspecialchars($row['mw']); ?></td>
                <td><?php echo htmlspecialchars($row['TPSA']); ?></td>
                <td><?php echo htmlspecialchars($row['XLogP']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Pagination Links -->
    <div>
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="complib.php?page=<?php echo $i; ?>&searchField1=<?php echo urlencode($searchField1); ?>&searchValue1=<?php echo urlencode($searchValue1); ?>&searchField2=<?php echo urlencode($searchField2); ?>&searchValue2=<?php echo urlencode($searchValue2); ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
<?php endif; ?>
