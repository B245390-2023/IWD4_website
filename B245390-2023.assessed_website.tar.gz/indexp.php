<?php
// redir.php
session_start(); // Start the session to access session variables

// Check if the session variables for firstname and surname are set
if (empty($_SESSION['firstname']) || empty($_SESSION['surname'])) {
    // Redirect to the complib.php with the full URL
    header("Location: https://bioinfmsc8.bio.ed.ac.uk/~s2478435/complib.php");
    exit;
}
?>

