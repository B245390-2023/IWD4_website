<?php
include 'login.php'; // login.php must create a PDO connection in $conn
include 'redir.php'; // redir.php checks session variables

session_start(); // Start the session

// Try to get statistics from the database
try {
    $stmt = $conn->query("SELECT COUNT(*) as Count, AVG(mw) as AvgMW FROM Compounds");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo "Total Compounds: " . htmlspecialchars($result['Count']) . "<br>";
    echo "Average Molecular Weight: " . htmlspecialchars(number_format($result['AvgMW'], 2)) . "<br>";
} catch (PDOException $e) {
    exit('Database query failed: ' . $e->getMessage());
}
?>
