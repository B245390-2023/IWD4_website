<?php
include 'login.php'; // Ensure that $conn is your PDO connection variable
include 'redir.php'; // Redirects if necessary

// HTML form for searching compounds
?>
<form action="p2.php" method="post">
    Enter NATM: <input type="text" name="natm"><br>
    Enter NSUL: <input type="text" name="nsul"><br>
    <input type="submit" name="search" value="Search">
</form>
<?php

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search'])) {
    // Capture the input values and sanitize them
    $natm = filter_input(INPUT_POST, 'natm', FILTER_SANITIZE_NUMBER_INT);
    $nsul = filter_input(INPUT_POST, 'nsul', FILTER_SANITIZE_NUMBER_INT);

    // Check for empty input
    if ($natm !== false && $nsul !== false && $natm !== null && $nsul !== null) {
        // If search is submitted, show results
        $stmt = $conn->prepare("SELECT * FROM Compounds WHERE natm = :natm AND nsul = :nsul");
        $stmt->execute([':natm' => $natm, ':nsul' => $nsul]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($results) {
            foreach ($results as $row) {
                // Display the results
                echo "ID: " . htmlspecialchars($row['id']) . " - NATM: " . htmlspecialchars($row['natm']) . " - NSUL: " . htmlspecialchars($row['nsul']) . "<br>";
            }
        } else {
            echo "No compounds found with the specified atomic composition.";
        }
    } else {
        echo "Please enter valid numbers for NATM and NSUL.";
    }
}
?>
