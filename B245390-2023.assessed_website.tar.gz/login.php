<?php
// login.php
// IMPORTANT: Ensure this file is properly secured and not accessible via the web.

$servername = "127.0.0.1";
$username = "s2478435"; // UNN.
$password = "zc!Student20232023"; // MySQL password.
$dbname = "s2478435_website"; // database name.

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // For persistent connections, uncomment the following line
    // $conn->setAttribute(PDO::ATTR_PERSISTENT, true);
} catch (PDOException $e) {
    // In a production environment, you should log this to a file instead
    error_log("Connection failed: " . $e->getMessage());
    exit;
}
?>
