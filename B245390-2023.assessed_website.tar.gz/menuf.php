<?php
// menuf.php
$baseURL = "https://bioinfmsc8.bio.ed.ac.uk/~s2478435"; // Base URL for all links

echo '<nav>';
echo "<a href='{$baseURL}/complib.php'>Home</a> | ";
echo "<a href='{$baseURL}/p1.php'>Select Suppliers</a> | ";
echo "<a href='{$baseURL}/p2.php'>Search Compounds</a> | ";
echo "<a href='{$baseURL}/p3.php'>Statistics</a> | ";
echo "<a href='{$baseURL}/p4.php'>Correlations</a> | ";
echo "<a href='{$baseURL}/p5.php'>Logout</a>";
echo '</nav>';
?>
