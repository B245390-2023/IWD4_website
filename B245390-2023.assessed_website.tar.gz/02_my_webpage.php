<html>
<head>
</head>
<body>
<?php
echo "Hello world";
echo "Hello from Edinburgh...\n";
$temp="<br/>The surrent date and time here is:<br/>\n";
$now=date('l js \of F Y h:i:s A');
echo "<br/>".$temp.$now." UTC\n";

?>
Bye!
</body>
</html>
