<?php
session_start();

// Unset all session values 
$_SESSION = array();

// Destroy the session 
session_destroy();

// Redirect to the login page or home page after logout
header("Location: complib.php");
exit;
?>
