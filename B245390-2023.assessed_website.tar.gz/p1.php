<?php
ob_start();
session_start();

// Include the login and redirection scripts
include 'login.php'; // login.php should create a PDO object named $pdo
include 'redir.php'; // redir.php will redirect if firstname or surname are not set

// Try to get all suppliers from the database
try {
    $stmt = $pdo->prepare("SELECT id, name FROM Manufacturers"); // Assuming the table name is Manufacturers
    $stmt->execute();
    $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    exit('Connection failed: ' . $e->getMessage());
}

// Check if the form is submitted and process the data
if (isset($_POST['submit']) && !empty($_POST['supplier'])) {
    $selectedSuppliers = $_POST['supplier'];
    $supmask = array_sum(array_map(fn($id) => 1 << ($id - 1), $selectedSuppliers));
    $_SESSION['supmask'] = $supmask;
    header("Location: p2.php");
    exit;
}

// Generate a form to let the user select active suppliers
?>
<form action="p1.php" method="post">
<?php foreach ($suppliers as $supplier): ?>
    <input type='checkbox' name='supplier[]' value='<?= htmlspecialchars($supplier['id']) ?>'> <?= htmlspecialchars($supplier['name']) ?><br>
<?php endforeach; ?>
    <input type="submit" name="submit" value="Select Suppliers">
</form>
<?php
ob_end_flush();
?>
